<?php 
// Create var to absolute path
define('ABSPATH', dirname(__FILE__).'/');

// Database info
define('DB_HOST', 'localhost');
define('DB_NAME', 'cinema');
define('DB_USER', 'root');
define('DB_PASS', 'root'); 


 ?>

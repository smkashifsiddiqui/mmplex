<?php 
/**
* INVENTORY MAIN CLASS
*/
class screen extends database
{
	private $table_name;

	function __construct()
	{
		parent::__construct();
		$this->table_name = 'screens';
		$this->table_seats	= 'screen_seats';
	}

	public function insert_screen($form)
	{
		$data = array();

		$data['screen_name'] = $form['screen_name'];
		$data['screen_total_seats'] = $form['screen_total_seats'];
		$data['screen_house_seats'] = $form['screen_house_seats'];
		$data['screen_wheel_chair_seats'] = $form['screen_wheel_chair_seats'];
		if(isset($form['screen_seat_layout_diagram'])){$data['screen_seat_layout_diagram'] = $form['screen_seat_layout_diagram'];}

		
		if(isset($form['screen_rows'])){
		$this->insert($this->table_name, $data);}
		else {
			return false;
		} 

		if($this->row_count() > 0){
			$screen_id = $this->last_id();
		}
		else {
			return false;
		} 
		
		
		// Sales Products Insert in Sale Products Table

		if($screen_id){
			$counter = 0;
			if(isset($form['screen_rows'])){
			foreach ($form['screen_rows'] as $value) {
				$seats['screen_seats_screen_id'] = $screen_id;
				$seats['screen_seats_row'] = $form['screen_rows'][$counter];
				$seats['screen_seats_row_column'] = $form['screen_seats_row_column'][$counter];
				//print_f($seats);
				$this->insert($this->table_seats, $seats);
				$counter++;
		}
			return true;
	   }
			
		}else {
			return false;
		} 
		

	} // end of insert

	public function update_screen($form, $id)
	{
		
		
		$data = array();

		$data['screen_name'] = $form['screen_name'];
		$data['screen_total_seats'] = $form['screen_total_seats'];
		$data['screen_house_seats'] = $form['screen_house_seats'];
		$data['screen_wheel_chair_seats'] = $form['screen_wheel_chair_seats'];
		if(isset($form['screen_seat_layout_diagram'])){$data['screen_seat_layout_diagram'] = $form['screen_seat_layout_diagram'];}

		$this->where('screen_id', $id);
		$this->update($this->table_name, $data);

		// Offer Products Delete Only Latest Product for Offer Table
		$this->where('screen_seats_screen_id', $id);
		$this->delete($this->table_seats, $num_rows = NULL);

		// Offer Products Insert in Offer Table
		
			$counter = 0;
			if(isset($form['screen_rows'])){
			foreach ($form['screen_rows'] as $value) {
				$seats['screen_seats_screen_id'] = $id;
				$seats['screen_seats_row'] = $form['screen_rows'][$counter];
				$seats['screen_seats_row_column'] = $form['screen_seats_row_column'][$counter];
				//print_f($seats);
				$this->insert($this->table_seats, $seats);
				$counter++;
		}
			return true;
	   }else {
			return false;
		} 

	} // end of update

	


	public function get_screens($ID = NULL)
	{
		if (isset($ID)) {
			$this->where('screen_id',$ID);
			$this->from($this->table_name);
			return $this->result();
		}
		else {
			$this->from($this->table_name);
			return $this->all_results();
		}
	} // end of get

	public function get_screen_seats($ID = NULL)
	{
		
			$this->where('screen_id',$ID);
			$this->from($this->table_name);
			return $this->all_results();
		
	} // end of get

	


} // end of class


 ?>
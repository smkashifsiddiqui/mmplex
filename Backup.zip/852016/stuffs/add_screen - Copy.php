<?php require_once 'header.php'; ?>

	<div class="container">

	<div class="row">
		<ol class="breadcrumb">
		  <li><a href="dashboard.php">Home</a></li>
		  <li><a href="view_screen.php">Screens</a></li>
		  <li class="active"><?php echo (isset($_GET['id']))? 'Update' : 'Add' ?> Screen</li>
		</ol>
	</div><!--row-->


	<div class="row form-header">
				<div class="col-md-12">
			 		<h3><?php echo (isset($_GET['id']))? 'Update' : 'Add' ?> Screen</h3>
			 	</div>
	 </div><!--row-->		
			<?php 
			$screen = new screen();
			
			
			$ID = (isset($_GET['id']))? $_GET['id'] : NULL;
			if (isset($_POST['add_screen'])) {		
				// Update old record
				if (isset($ID)) {
					$results = $screen->update_screen($_POST, $ID);
					
				}else{ // Insert new
					$results = $screen->insert_screen($_POST);
					
				}
				if ($results) {
					echo '<div class="alert alert-success" role="alert"> Added screen Sucessfully </div>';
				}else{
					echo '<div class="alert alert-danger" role="alert"> Error </div>';
				}
			}
			if (isset($ID)) {
				$screen_result = $screen->get_screens($ID);
				$screen_seats_result = $screen->get_screen_seats($ID);
				//print_f($screen_seats_result);

			}
			?>

	<form class="form-horizontal dashboardForm"  action="" method="post">
			<div class="form-container">
				<div class="col-md-12 top-label">
					<div class="col-md-6">
						<h3>Screen Detail: </h3>
				 	</div>
					<div class="col-md-6 form-header-right">
						<button type="submit" class="btn submitBtn save-button" name="add_screen"><?php echo (isset($_GET['id']))? 'Update' : 'Add' ?> screen </button>
					</div>
				</div>

			<div class="col-md-6">
				<div class="col-md-12">	
					<div class="form-group">
						<label for="screen_name" class="col-sm-4 control-label">Screen Name: </label>
						<div class="col-sm-8">
							<input type="text" name="screen_name" id="screen_name" value="<?php echo (isset($ID))? $screen_result->screen_name : '' ?>" class="form-control" required>
						</div>
					</div>
				</div>
				<div class="clear"></div>
				<div class="col-md-12">	
					<div class="form-group">
						<label for="screen_total_seats" class="col-sm-4 control-label">Total Seats: </label>
						<div class="col-sm-8">
							<input type="text" name="screen_total_seats" id="screen_total_seats" value="<?php echo (isset($ID))? $screen_result->screen_total_seats : '' ?>" class="form-control" >
						</div>
					</div>
				</div>

				<div class="clear"></div>
				<div class="col-md-12">	
					<div class="form-group">
						<label for="screen_house_seats" class="col-sm-4 control-label">House Seats: </label>
						<div class="col-sm-8">
							<input type="text" name="screen_house_seats" id="screen_house_seats" value="<?php echo (isset($ID))? $screen_result->screen_house_seats : '' ?>" class="form-control" >
						</div>
					</div>
				</div>
				
				<div class="clear"></div>

				<div class="col-md-12">	
					<div class="form-group">
						<label for="screen_wheel_chair_seats" class="col-sm-4 control-label">Wheel Chair Seats: </label>
						<div class="col-sm-8">
							<input type="text" name="screen_wheel_chair_seats" id="screen_wheel_chair_seats" value="<?php echo (isset($ID))? $screen_result->screen_wheel_chair_seats : '' ?>" class="form-control" >
						</div>
					</div>
				</div>

				<div class="col-md-12">	
					<div class="form-group">
						<label for="screen_seat_layout_diagram" class="col-sm-4 control-label">Seat Layout Diagram: </label>
						<div class="col-sm-8">
							<input type="file" name="screen_seat_layout_diagram" id="screen_seat_layout_diagram" value="<?php echo (isset($ID))? $screen_result->screen_seat_layout_diagram : '' ?>" class="form-control" >
						</div>
					</div>
				</div>
			
			</div><!-- col-md-6 -->

			<div class="col-md-4 col-md-offset-2">
				<div class="col-md-12 screen_layout_img">
				<img width="100%" src="assets/images/<?php echo (isset($ID))? $screen_result->screen_seat_layout_diagram : '' ?>"/>
				</div>
			</div><!-- col-md-6 -->

	<div class="col-md-12 bottom-label">
		<div class="col-md-6">
			<h3>Rows and Seats count.</h3>
			<span>Add or remove Rows and their seats for this screen below</span>
		</div>

		<div class="col-md-6 form-header-right">
			<button type="button" class="btn submitBtn save-button" value="" onclick="addRow()">Add Row</button>
		</div>
	</div><!-- col-md-12 -->


			<div class="col-md-12 ">
					<div id="content">
					<?php if(isset($ID)){
						foreach($screen_seats_result as $res ){	
							$current_rows = $res->screen_seats_row;
							$current_column = $res->screen_seats_row_column;?>
							<div class="row">
							<div class="col-md-12 row-el">
								<div class="col-md-4">
									<div class="form-group">
										<label class="col-sm-4 control-label">Row</label>
										<div class="col-sm-8">
											<select name="screen_rows[]" class="form-control" required>
											<option value="" selected disabled>Select Row</option>
											<?php foreach($screen_rows as $screen_rows_key => $screen_rows_value){?><option value="<?php echo $screen_rows_key ;?>" <?php if($current_rows == $screen_rows_key){echo 'selected=selected';}?>><?php echo $screen_rows_value ;?></option>
											<?php } ?>
											</select>
										</div>
								  	</div>
								</div>
								<div class="col-md-5">
									<div class="form-group">
										<label class="col-sm-5 control-label">Seats per Row</label>
										<div class="col-sm-6">
											<input type="number" name="screen_seats_row_column[]" id="row_columns" value="<?php echo $current_column; ?>" class="form-control" required>
										</div>
									</div>
								</div>
									<div class="col-md-3 txt-center">
										<button type="button" class="btn submitBtn minus-btn" value="" >Remove x</button>
									</div>
								</div>
								</div>
						<?php }?>
						<?php }?>
					</div><!-- #Content CLose -->
				</div><!-- col-md-12 -->	

		 </div><!-- form-container -->
	  </form>
	</div><!-- Container Close -->

<?php require_once 'include/short_scripts/screen_script.php'; ?>
<?php require_once 'footer.php'; ?>